Marvin M6S + Handle-L1 right_handv5。7路机械臂、6路灵巧手主动控制，5个从动关节随动。Run后在Parameters调整各关节；布局改变后需重新规划抓取轨迹。参数尚未完成真机标定。
