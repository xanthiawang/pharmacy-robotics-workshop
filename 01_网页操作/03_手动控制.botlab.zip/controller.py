from botlab import Robot, PolicyController, constant, project, state_machine, concat
project('Pharmacy Handle-L1 layout workshop', control_hz=50, physics_hz=500, parameters={'joint_0': {'label': 'arm/Joint1_R', 'default': 0.0, 'range': [-3.1067, 3.1067], 'step': 0.01, 'unit': 'rad'}, 'joint_1': {'label': 'arm/Joint2_R', 'default': 0.6, 'range': [-2.0944, 2.0944], 'step': 0.01, 'unit': 'rad'}, 'joint_2': {'label': 'arm/Joint3_R', 'default': 0.0, 'range': [-3.1067, 3.1067], 'step': 0.01, 'unit': 'rad'}, 'joint_3': {'label': 'arm/Joint4_R', 'default': -1.6, 'range': [-2.5307, 1.0472], 'step': 0.01, 'unit': 'rad'}, 'joint_4': {'label': 'arm/Joint5_R', 'default': 0.0, 'range': [-3.1067, 3.1067], 'step': 0.01, 'unit': 'rad'}, 'joint_5': {'label': 'arm/Joint6_R', 'default': 0.8, 'range': [-1.0472, 1.0472], 'step': 0.01, 'unit': 'rad'}, 'joint_6': {'label': 'arm/Joint7_R', 'default': 0.0, 'range': [-1.5708, 1.5708], 'step': 0.01, 'unit': 'rad'}, 'joint_7': {'label': 'hand/right_thumb_mcp_roll_joint2', 'default': 0.0, 'range': [0.0, 2.0944], 'step': 0.01, 'unit': 'rad'}, 'joint_8': {'label': 'hand/right_thumb_mcp_pitch_joint3', 'default': 0.0, 'range': [0.0, 0.5236], 'step': 0.01, 'unit': 'rad'}, 'joint_9': {'label': 'hand/right_index_mcp_joint5', 'default': 0.0, 'range': [0.0, 1.4], 'step': 0.01, 'unit': 'rad'}, 'joint_10': {'label': 'hand/right_middle_mcp_joint7', 'default': 0.0, 'range': [0.0, 1.4], 'step': 0.01, 'unit': 'rad'}, 'joint_11': {'label': 'hand/right_ring_mcp_joint9', 'default': 0.0, 'range': [0.0, 1.4], 'step': 0.01, 'unit': 'rad'}, 'joint_12': {'label': 'hand/right_pinky_mcp_joint11', 'default': 0.0, 'range': [0.0, 1.4], 'step': 0.01, 'unit': 'rad'}})
robot = Robot('assets/pharmacy/pharmacy.xml', name='Pharmacy', config={'actionDimension': 13, 'jointQposOffset': 0, 'jointQvelOffset': 0, 'initialQpos': [0.0, 0.6, 0.0, -1.6, 0.0, 0.8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.299999976158142, 3.1200000953674314, 0.762, 1.0, 0.0, 0.0, 0.0], 'initialQvel': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 'defaultJointPositions': [0.0, 0.6, 0.0, -1.6, 0.0, 0.8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 'policyJointOrder': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 'motorJointOrder': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 'actuatorJointOrder': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 'actionScale': 1})

def create_controller(sim):
    controls = []
    controls.append(robot.commands('joint_0'))
    controls.append(robot.commands('joint_1'))
    controls.append(robot.commands('joint_2'))
    controls.append(robot.commands('joint_3'))
    controls.append(robot.commands('joint_4'))
    controls.append(robot.commands('joint_5'))
    controls.append(robot.commands('joint_6'))
    controls.append(robot.commands('joint_7'))
    controls.append(robot.commands('joint_8'))
    controls.append(robot.commands('joint_9'))
    controls.append(robot.commands('joint_10'))
    controls.append(robot.commands('joint_11'))
    controls.append(robot.commands('joint_12'))
    return PolicyController(robot, control=concat(controls).action())
